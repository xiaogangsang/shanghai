环境需要：
nodejs & npm
npm使用淘宝源：
```
alias cnpm="npm --registry=https://registry.npm.taobao.org \
--cache=$HOME/.npm/.cache/cnpm \
--disturl=https://npm.taobao.org/dist \
--userconfig=$HOME/.cnpmrc"
```

安装：
`npm install`
`bower install`

开发：
`gulp dev`

发布：
`gulp`

接口：
_UAT_ `http://180.169.45.105/MovieOps/`