var common = require('common');
var _channels = {};
var _pageIndex = 1;
var _pageSize = 10;
var _pageTotal = 0;
var searchCache = {};
var useCache = false;

$(function() {
  common.setMenu('report');
  setChannel();
  setSource();
  setCity();
  setBrand();
  setCinema();
  // setActivity();

  $.fn.datetimepicker.dates['zh-CN'] = {
    days: ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六", "星期日"],
    daysShort: ["周日", "周一", "周二", "周三", "周四", "周五", "周六", "周日"],
    daysMin:  ["日", "一", "二", "三", "四", "五", "六", "日"],
    months: ["一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"],
    monthsShort: ["一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"],
    today: "今天",
    suffix: [],
    meridiem: ["上午", "下午"]
  };
  $('#search_beginDate,#search_endDate').datetimepicker({format: 'yyyy-mm-dd', language: 'zh-CN', todayHighlight: true, minView:2, autoclose: true});
  var beginDate = new Date();
  var endDate = new Date();
  endDate.setDate(endDate.getDate()+7);
  beginDate = common.getDate(beginDate);
  endDate = common.getDate(endDate);
  $('#search_beginDate').val(beginDate);
  $('#search_endDate').val(endDate);
});

//handle search form
$('#formSearch').on('submit', function(e) {
  e.preventDefault();
  var sendData = {
    beginDate: $('#search_beginDate').val(),
    endDate: $('#search_endDate').val(),
    channelId: $('#search_channelId').val(),
    partnerId: $('#search_partnerId').val(),
    cityId: $('#search_cityId').val(),
    brandId: $('#search_brandId').val(),
    storeId: $('#search_storeId').val(),
    productName: $.trim( $('#search_productName').val() ),
    activityId: $.trim( $('#search_activityId').val() ),
    pageSize: _pageSize
  };
  if (useCache) {
    sendData = searchCache;
  } else {
    searchCache = sendData;
  }
  sendData.pageIndex = _pageIndex;
  // console.log(sendData);
  $.ajax({
    url: common.API_HOST + 'order/reportList',
    type: 'POST',
    dataType: 'json',
    data: sendData
  })
  .done(function(res) {
    console.log(res);
    if (true == res.meta.result) {
      if (res.data == null || res.data.length < 1) {
        $('#dataTable tbody').html('<tr><td colspan="15" align="center">查不到相关数据，请修改查询条件！</td></tr>');
        return false;
      } else {
        useCache = true;
        _pageIndex = res.data.pageIndex;
        _pageTotal = Math.ceil(res.data.total/_pageSize);
        setPager(res.data.total, _pageIndex, res.data.length, _pageTotal);
        _(res.data.retList).forEach(function(item){
          _(_channels).forEach(function(channel){
            if (item.channelId == channel.channelId) {
              item.channelName = channel.channelName;
            }
          });
        });
        setTableData(res.data);
      }
    } else {
      alert('接口错误：'+res.meta.msg);
    }
  });
  return false;
});

$('#pager').on('click', '.prev,.next', function(e) {
  e.preventDefault();
  if ($(this).hasClass('prev')) {
    if (_pageIndex <= 1) {
      _pageIndex = 1;
      alert('已经是第一页！');
      return false;
    }
    _pageIndex--;
  } else {
    if (_pageIndex >= _pageTotal) {
      _pageIndex = _pageTotal;
      alert('已经是最后一页！');
      return false;
    }
    _pageIndex++
  }
  $("#formSearch").trigger('submit');
  return false;
});
$('#formSearch').on('click', 'button[type=submit]', function(event) {
  event.preventDefault();
  _pageIndex = 1;
  useCache = false;
  $("#formSearch").trigger('submit');
});
$('#pager').on('click', '#btn-pager', function(e) {
  e.preventDefault();
  if ('' ==$('#pageNo').val()) {
    return false;
  }
  var pageNo = parseInt( $('#pageNo').val() );
  if (NaN == pageNo || pageNo < 1 || pageNo > _pageTotal) {
    alert('要跳转的页码超过了范围！');
    return false;
  }
  _pageIndex = pageNo;
  $("#formSearch").trigger('submit');
  return false;
});

function setTableData(data) {
  var data = {rows:data.retList, totalAmountAll:data.totalAmountAll};
  var template = $('#table-template').html();
  Mustache.parse(template);
  var html = Mustache.render(template, data);
  $('#dataTable tbody').html(html);
}
function setPager(total, pageIndex, rowsSize, pageTotal) {
  var data = {total:total,pageIndex:pageIndex,rowsSize:rowsSize,pageTotal:pageTotal};
  var template = $('#pager-template').html();
  Mustache.parse(template);
  var html = Mustache.render(template, data);
  $('#pager').html(html);
}

function setChannel() {
  $.ajax({
    url: common.API_HOST + 'common/channelList',
    type: 'GET',
    dataType: 'json'
  })
  .done(function(res) {
    // console.log(res);
    if (true == res.meta.result) {
      _channels = res.data;
      var html = '';
      _(_channels).forEach(function(channel){
        html += '<option value="'+channel.channelId+'">'+channel.channelName+'</option>';
      });
      $('#search_channelId').append(html);
    } else {
      alert('获取渠道列表失败：'+res.meta.msg);
    }
  });
}
function setSource() {
  $.ajax({
    url: common.API_HOST + 'common/sourceList',
    type: 'GET',
    dataType: 'json'
  })
  .done(function(res) {
    // console.log(res);
    if (true == res.meta.result) {
      var html = '';
      _(res.data).forEach(function(source){
        html += '<option value="'+source.sourceId+'">'+source.sourceName+'</option>';
      });
      $('#search_partnerId').append(html);
    } else {
      alert('获取渠道列表失败：'+res.meta.msg);
    }
  });
}
function setCity() {
  $.ajax({
    url: common.API_HOST + 'common/cityList',
    type: 'GET',
    dataType: 'json'
  })
  .done(function(res) {
    // console.log(res);
    if (true == res.meta.result) {
      var _cities = [];
      _(res.data).forEach(function(group){
        _(group).forEach(function(city){
          _cities.push( city );
        });
      });
      var html = '';
      $.each(_cities, function(index, item) {
        html += '<option value="'+item.cityId+'">'+item.cityName+'</option>';
      });
      $('#search_cityId').append(html)
      $("#search_cityId").chosen();
    }
  });
}
function setBrand() {
  $.ajax({
    url: common.API_HOST + 'common/brandList',
    type: 'GET',
    dataType: 'json'
  })
  .done(function(res) {
    // console.log(res);
    if (true == res.meta.result) {
      var html = '';
      _(res.data).forEach(function(brand){
        html += '<option value="'+brand.id+'">'+brand.name+'</option>';
      });
      $('#search_brandId').append(html);
    } else {
      alert('接口错误：'+res.meta.msg);
    }
  });
}
function setCinema() {
  $.ajax({
    url: common.API_HOST + 'common/cinemaList',
    type: 'POST',
    dataType: 'json'
  })
  .done(function(res) {
    console.log(res);
    if (true == res.meta.result) {
      var html = '';
      _(res.data).forEach(function(cinema){
        html += '<option value="'+cinema.cinemaId+'">'+cinema.cinemaName+'</option>';
      });
      $('#search_storeId').append(html).chosen();
    } else {
      alert('接口错误：'+res.meta.msg);
    }
  });
}
// function setActivity() {
//   $.ajax({
//     url: common.API_HOST + 'plan/planList',
//     type: 'POST',
//     dataType: 'json',
//     data: {
//       pageIndex: 1,
//       pageSize: 9999
//     }
//   })
//   .done(function(res) {
//     // console.log(res);
//     if (true == res.meta.result) {
//       var html = '';
//       _(res.data.rows).forEach(function(plan){
//         html += '<option value="'+plan.id+'">'+plan.name+'</option>';
//       });
//       $('#search_activityId').append(html);
//     } else {
//       alert('接口错误：'+res.meta.msg);
//     }
//   });
// }