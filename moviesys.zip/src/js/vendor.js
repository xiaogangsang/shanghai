require('jquery');
require('cookie');
require('bootstrap');

require('lodash');
require('mustache');
require('parsley');
require('parsley-lang');
require('multiselect');
require('chosen');
require('datetimepicker');